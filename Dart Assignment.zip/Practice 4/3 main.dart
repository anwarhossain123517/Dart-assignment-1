import 'dart:io';

void main() {
  List<double> expenses = [];
  print('Enter expenses (type "done" to finish):');

  while (true) {
    stdout.write('Enter amount: ');
    String? input = stdin.readLineSync();
    
    if (input == null || input.toLowerCase() == 'done') {
      break;
    }

    double? amount = double.tryParse(input);
    if (amount != null) {
      expenses.add(amount);
    } else {
      print('Invalid input. Please enter a valid number.');
    }
  }

  double total = expenses.fold(0, (sum, element) => sum + element);
  print('\nTotal Expenses: \$${total.toStringAsFixed(2)}');
}