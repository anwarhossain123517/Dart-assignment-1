void main() {
  List<String> names = ['Alice', 'Bob', 'Charlie', 'Diana'];
  print('Names in the list:');
  for (String name in names) {
    print(name);
  }
}