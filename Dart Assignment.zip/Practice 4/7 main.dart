void main() {
  Map<String, String> phoneBook = {
    'John': '555-0101',
    'Amy': '555-0192',
    'Mike': '555-0342',
    'Alex': '555-0999',
    'Bob': '555-4321',
  };

  // Find all keys that have a length of 4
  var keysWithLength4 = phoneBook.keys.where((key) => key.length == 4).toList();

  print('Keys with length 4: $keysWithLength4');
}