void main() {
  Map<String, dynamic> person = {
    'name': 'John Doe',
    'address': '123 Main St',
    'age': 28,
    'country': 'USA',
  };

  // Update country name
  person['country'] = 'Canada';

  print('Updated Person Details:');
  person.forEach((key, value) {
    print('$key: $value');
  });
}