void main() {
  Set<String> fruits = {'Apple', 'Banana', 'Mango', 'Orange'};
  print('Fruits in the set:');
  for (String fruit in fruits) {
    print(fruit);
  }
}