void main() {
  List<String> friends = ['Alice', 'Benjamin', 'Charlie', 'Amanda', 'David', 'Aaron', 'Fiona'];

  // Find names starting with 'a' or 'A' using where()
  var filteredFriends = friends.where((friend) => friend.toLowerCase().startsWith('a')).toList();

  print('Friends whose names start with "A":');
  for (String friend in filteredFriends) {
    print(friend);
  }
}