import 'dart:io';

void main() {
  List<String> tasks = [];

  while (true) {
    print('\n--- To-Do Application ---');
    print('1. View Tasks');
    print('2. Add Task');
    print('3. Remove Task');
    print('4. Exit');
    stdout.write('Choose an option (1-4): ');

    String? choice = stdin.readLineSync();

    switch (choice) {
      case '1':
        if (tasks.isEmpty) {
          print('\nYour to-do list is empty.');
        } else {
          print('\nYour Tasks:');
          for (int i = 0; i < tasks.length; i++) {
            print('${i + 1}. ${tasks[i]}');
          }
        }
        break;

      case '2':
        stdout.write('\nEnter the task to add: ');
        String? newTask = stdin.readLineSync();
        if (newTask != null && newTask.trim().isNotEmpty) {
          tasks.add(newTask.trim());
          print('Task added successfully!');
        } else {
          print('Task cannot be empty.');
        }
        break;

      case '3':
        if (tasks.isEmpty) {
          print('\nNo tasks to remove.');
          break;
        }
        print('\nCurrent Tasks:');
        for (int i = 0; i < tasks.length; i++) {
          print('${i + 1}. ${tasks[i]}');
        }
        stdout.write('Enter the number of the task to remove: ');
        String? indexInput = stdin.readLineSync();
        int? index = int.tryParse(indexInput ?? '');

        if (index != null && index > 0 && index <= tasks.length) {
          String removed = tasks.removeAt(index - 1);
          print('Removed task: "$removed"');
        } else {
          print('Invalid task number.');
        }
        break;

      case '4':
        print('\nExiting To-Do App. Goodbye!');
        return;

      default:
        print('\nInvalid choice. Please select between 1 and 4.');
    }
  }
}