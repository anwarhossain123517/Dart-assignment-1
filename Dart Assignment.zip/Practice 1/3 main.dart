void main() {
  const int myNumber = 7;
  print("Constant integer value: $myNumber");
}