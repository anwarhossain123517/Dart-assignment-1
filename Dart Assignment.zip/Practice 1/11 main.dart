void main() {
  double totalBill = 240.0;
  int numberOfPeople = 5;
  
  double splitAmount = totalBill / numberOfPeople;
  print("Each person has to pay: \$$splitAmount");
}