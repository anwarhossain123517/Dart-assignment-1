void main() {
  int num1 = 17;
  int num2 = 4;
  
  int quotient = num1 ~/ num2; // Integer division
  int remainder = num1 % num2;
  
  print("Quotient: $quotient");
  print("Remainder: $remainder");
}