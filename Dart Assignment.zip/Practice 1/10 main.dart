void main() {
  String numberString = "42";
  int convertedInt = int.parse(numberString);
  
  print("Converted value: $convertedInt");
  print("Data type: ${convertedInt.runtimeType}");
}