void main() {
  double p = 1000.0; // Principal amount
  double t = 2.0;    // Time in years
  double r = 5.0;    // Annual interest rate
  
  double simpleInterest = (p * t * r) / 100;
  print("Simple Interest: $simpleInterest");
}