void main() {
  double distance = 25.0; // km
  double speed = 40.0;    // km/h
  
  // Formula: time (hours) = distance / speed
  double timeInHours = distance / speed;
  double timeInMinutes = timeInHours * 60;
  
  print("Time taken to reach office: $timeInMinutes minutes");
}