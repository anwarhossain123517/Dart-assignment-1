void main() {
  String textWithSpaces = "D a r t   P r o g r a m m i n g";
  String result = textWithSpaces.replaceAll(' ', '');
  
  print("Original: $textWithSpaces");
  print("Without spaces: $result");
}