void createUser(String name, int age, {bool isActive = true}) {
  print("User Profile -> Name: $name, Age: $age, Active: $isActive");
}

void main() {
  createUser("Alice", 28);                  // Uses default isActive = true
  createUser("Bob", 32, isActive: false);   // Overrides isActive to false
}