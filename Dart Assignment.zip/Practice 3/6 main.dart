String reverseString(String str) {
  return str.split('').reversed.join('');
}

void main() {
  String text = "Dart Programming";
  print("Reversed: ${reverseString(text)}");
}