double calculateArea({double length = 1.0, double width = 1.0}) {
  return length * width;
}

void main() {
  print("Default rectangle area: ${calculateArea()}");               // Output: 1.0
  print("Custom rectangle area (5x4): ${calculateArea(length: 5, width: 4)}"); // Output: 20.0
}