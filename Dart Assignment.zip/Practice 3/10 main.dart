bool isEven(int number) {
  return number % 2 == 0;
}

void main() {
  print("Is 4 even? ${isEven(4)}"); // Output: true
  print("Is 7 even? ${isEven(7)}"); // Output: false
}