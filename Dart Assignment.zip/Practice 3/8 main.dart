num add(num a, num b) {
  return a + b;
}

void main() {
  print("Sum: ${add(15, 25)}");
}