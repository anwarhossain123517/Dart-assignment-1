num maxNumber(num a, num b, num c) {
  return [a, b, c].reduce((curr, next) => curr > next ? curr : next);
}

void main() {
  print("Largest number: ${maxNumber(12, 45, 23)}");
}