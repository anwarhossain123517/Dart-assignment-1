import 'dart:math';

num calculatePower(num base, num exponent) {
  return pow(base, exponent);
}

void main() {
  print("5^3 = ${calculatePower(5, 3)}"); // Output: 125
}