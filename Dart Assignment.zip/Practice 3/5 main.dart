import 'dart:math';

double calculateCircleArea(double radius) {
  return pi * radius * radius;
}

void main() {
  double radius = 5.0;
  print("Area of the circle: ${calculateCircleArea(radius)}");
}