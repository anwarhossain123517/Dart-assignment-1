import 'dart:io';

void main() async {
  File original = File('hello.txt');
  
  if (await original.exists()) {
    await original.copy('hello_copy.txt');
    print('File copied successfully to hello_copy.txt');
  } else {
    print('hello.txt does not exist.');
  }
}