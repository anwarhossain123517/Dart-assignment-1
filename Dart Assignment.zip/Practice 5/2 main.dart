import 'dart:io';

void main() {
  File file = File('hello.txt');
  // mode: FileMode.append preserves existing content
  file.writeAsStringSync('Jane Smith\n', mode: FileMode.append);
  print('Friend name appended successfully.');
}