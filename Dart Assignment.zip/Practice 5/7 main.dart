import 'dart:io';

void main() async {
  File csvFile = File('students.csv');

  // 1. Write student data to CSV
  String csvData = 'Name,Age,Address\n'
      'Alice,20,New York\n'
      'Bob,22,Los Angeles\n'
      'Charlie,21,Chicago\n';

  await csvFile.writeAsString(csvData);
  print('Student data written to students.csv successfully.\n');

  // 2. Read student data from CSV
  if (await csvFile.exists()) {
    String contents = await csvFile.readAsString();
    print('Reading student data from CSV:');
    print(contents);
  }
}