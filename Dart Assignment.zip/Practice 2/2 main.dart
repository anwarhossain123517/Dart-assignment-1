void main() {
  String char = 'e';
  String lowerChar = char.toLowerCase();
  
  if ('aeiou'.contains(lowerChar)) {
    print('$char is a Vowel');
  } else {
    print('$char is a Consonant');
  }
}