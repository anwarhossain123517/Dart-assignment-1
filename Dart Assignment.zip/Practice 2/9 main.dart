void main() {
  for (int i = 1; i <= 100; i++) {
    if (i == 41) {
      continue; // Skips the number 41
    }
    print(i);
  }
}