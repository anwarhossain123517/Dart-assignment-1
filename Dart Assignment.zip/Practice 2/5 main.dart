void main() {
  int n = 10;
  int sum = 0;
  
  for (int i = 1; i <= n; i++) {
    sum += i;
  }
  
  print('The sum of natural numbers up to $n is $sum');
}