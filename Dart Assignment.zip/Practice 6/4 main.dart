class Car {
  Car.manual() {
    print('Manual car created.');
  }

  Car.automatic() {
    print('Automatic car created.');
  }
}

void main4() {
  var mCar = Car.manual();
  var aCar = Car.automatic();
}