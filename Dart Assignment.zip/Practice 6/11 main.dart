class Person {
  void displayInfo() => print('I am a person.');
}

class Teacher extends Person {
  @override
  void displayInfo() => print('I am a teacher.');
}

class StudentPerson extends Person {
  @override
  void displayInfo() => print('I am a student.');
}

void main11() {
  List<Person> people = [Person(), Teacher(), StudentPerson()];
  for (var p in people) {
    p.displayInfo();
  }
}