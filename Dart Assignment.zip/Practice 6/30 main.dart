abstract class SMSPerson {
  String name;
  SMSPerson(this.name);
  void displayRole();
}

class SMSStudent extends SMSPerson {
  SMSStudent(String name) : super(name);

  @override
  void displayRole() => print('Role: Student ($name)');
}

class Course {
  String courseName;
  Course(this.courseName);
}

class Enrollment {
  SMSStudent student;
  Course course;
  Enrollment(this.student, this.course);
}