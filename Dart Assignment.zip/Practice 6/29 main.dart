class LibraryBook {
  String title;
  bool isIssued = false;
  LibraryBook(this.title);
}

class Member {
  String name;
  Member(this.name);
}

class Library {
  List<LibraryBook> books = [];

  void issueBook(LibraryBook book) {
    if (!book.isIssued) {
      book.isIssued = true;
      print('Book "${book.title}" issued successfully.');
    } else {
      print('Book is already issued.');
    }
  }

  void returnBook(LibraryBook book) {
    book.isIssued = false;
    print('Book "${book.title}" returned successfully.');
  }
}