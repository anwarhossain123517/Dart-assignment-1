class SecureBankAccount {
  double _balance = 0.0;

  double get balance => _balance;

  set balance(double amount) {
    if (amount >= 0) {
      _balance = amount;
    } else {
      print('Error: Balance cannot be negative.');
    }
  }
}

void main10() {
  var acc = SecureBankAccount();
  acc.balance = 100;
  acc.balance = -50; // Triggers validation error
}