abstract class Shape {
  double calculateArea();
}

class RectShape extends Shape {
  double length, width;
  RectShape(this.length, this.width);

  @override
  double calculateArea() => length * width;
}

class CircleShape extends Shape {
  double radius;
  CircleShape(this.radius);

  @override
  double calculateArea() => 3.1416 * radius * radius;
}