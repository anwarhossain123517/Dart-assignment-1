abstract class Appliance {
  void turnOn();
  void turnOff();
}

class Fan implements Appliance {
  @override
  void turnOn() => print('Fan is ON.');
  @override
  void turnOff() => print('Fan is OFF.');
}