abstract class Payment {
  void processPayment();
}

class CashPayment extends Payment {
  @override
  void processPayment() => print('Payment processed via Cash.');
}

class CardPayment extends Payment {
  @override
  void processPayment() => print('Payment processed via Credit Card.');
}