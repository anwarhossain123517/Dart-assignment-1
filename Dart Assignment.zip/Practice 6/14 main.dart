class NotificationBase {
  String displayNotification() => 'General notification message.';
}

class EmailNotification extends NotificationBase {
  @override
  String displayNotification() => 'Email notification: You have a new message.';
}

class SMSNotification extends NotificationBase {
  @override
  String displayNotification() => 'SMS notification: Your code is 1234.';
}