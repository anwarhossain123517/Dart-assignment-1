class Employee {
  String name;
  String designation;
  double salary;

  Employee(this.name, this.designation, this.salary);
}

void main8() {
  List<Employee> employees = [
    Employee('Alice', 'Developer', 60000),
    Employee('Bob', 'Designer', 50000),
    Employee('Charlie', 'Manager', 80000),
  ];

  for (var emp in employees) {
    print('${emp.name} - ${emp.designation} - \$${emp.salary}');
  }
}