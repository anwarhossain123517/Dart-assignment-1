class CompanyEmployee {
  double calculateSalary() => 0.0;
}

class Manager extends CompanyEmployee {
  @override
  double calculateSalary() => 90000.0;
}

class Developer extends CompanyEmployee {
  @override
  double calculateSalary() => 75000.0;
}