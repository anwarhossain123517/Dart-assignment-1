class BankAccount {
  double balance = 0.0;

  void deposit(double amount) {
    if (amount > 0) balance += amount;
  }

  void withdraw(double amount) {
    if (amount <= balance) balance -= amount;
  }
}

void main6() {
  var account = BankAccount();
  account.deposit(500);
  account.withdraw(200);
  print('Balance: ${account.balance}');
}