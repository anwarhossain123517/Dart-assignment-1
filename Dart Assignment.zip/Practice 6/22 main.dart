mixin LoggerMixin {
  void logMessage(String message) => print('LOG: $message');
}

class User with LoggerMixin {}
class Product with LoggerMixin {}

void main22() {
  User().logMessage('User logged in.');
  Product().logMessage('Product stock updated.');
}