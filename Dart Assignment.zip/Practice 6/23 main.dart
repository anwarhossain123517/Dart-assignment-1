class Document {}

mixin Printable on Document {
  void display() => print('Displaying document content...');
}

class Invoice extends Document with Printable {}
class Report extends Document with Printable {}