class PersonBase {
  String name;
  PersonBase(this.name);
}

class EmployeeSub extends PersonBase {
  double salary;
  EmployeeSub(String name, this.salary) : super(name);
}