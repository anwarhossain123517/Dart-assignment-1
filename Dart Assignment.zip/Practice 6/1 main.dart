class Student {
  String name;
  int id;
  double cgpa;

  Student(this.name, this.id, this.cgpa);

  void display() {
    print('Student: $name, ID: $id, CGPA: $cgpa');
  }
}

void main1() {
  var student = Student('Alice', 101, 3.85);
  student.display();
}