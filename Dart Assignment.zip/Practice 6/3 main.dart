class Book {
  String title;
  String subtitle;
  String author;

  Book(this.title, this.subtitle, this.author);

  void displayInfo() {
    print('Book: "$title: $subtitle" by $author');
  }
}

void main3() {
  var book = Book('Dart Programming', 'A Modern Guide', 'John Doe');
  book.displayInfo();
}