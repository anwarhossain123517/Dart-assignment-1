abstract class AbstractShape {
  double calculateArea();
}

class Square extends AbstractShape {
  double side;
  Square(this.side);

  @override
  double calculateArea() => side * side;
}