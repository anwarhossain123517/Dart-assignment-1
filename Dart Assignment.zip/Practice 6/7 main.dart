class MathHelper {
  static double add(double a, double b) => a + b;
  static double multiply(double a, double b) => a * b;
}

void main7() {
  print('Addition: ${MathHelper.add(5, 3)}');
  print('Multiplication: ${MathHelper.multiply(4, 2)}');
}