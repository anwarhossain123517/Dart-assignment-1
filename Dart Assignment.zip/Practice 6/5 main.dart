class Customer {
  final String name;
  final int id;

  const Customer(this.name, this.id);
}

void main5() {
  const customer = Customer('Bob', 123);
  print('Customer: ${customer.name}, ID: ${customer.id}');
}