class Guest {
  String name;
  Guest(this.name);
}

class Room {
  int roomNumber;
  bool isAvailable;
  Room(this.roomNumber, this.isAvailable);
}

class Reservation {
  Guest guest;
  Room room;
  Reservation(this.guest, this.room);
}