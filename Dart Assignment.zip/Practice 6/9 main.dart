class Temperature {
  double _temp = 0.0; // in Celsius

  set celsius(double value) => _temp = value;

  double get fahrenheit => (_temp * 9 / 5) + 32;
}

void main9() {
  var t = Temperature();
  t.celsius = 25;
  print('Fahrenheit: ${t.fahrenheit}°F');
}